An untranslated article
=======================
:date: 2014-07-14
:lang: en

An article without a translation.
Here is a link to an `untranslated page`_

.. _`untranslated page`: {filename}/pages/untranslated-page.rst
