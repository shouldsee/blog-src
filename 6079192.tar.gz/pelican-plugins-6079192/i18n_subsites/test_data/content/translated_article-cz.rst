Přeložený článek
================
:slug: translated-article
:lang: cz
:date: 2014-09-15

Jednoduchý článek s překlady.
Zde je odkaz na `nějaký obrázek <{filename}/images/img.png>`_.
