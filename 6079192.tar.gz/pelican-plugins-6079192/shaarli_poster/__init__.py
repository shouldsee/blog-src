from .shaarli_poster import *
