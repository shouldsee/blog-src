Title: Dummy article
Category: test
Tags: foo, bar, foobar
Date: 2010-12-02 10:14
Modified: 2010-12-02 10:20
Summary: I have a lot to test

Test Markdown File Header
=========================

Used for pelican test
---------------------

The quick brown fox jumped over the lazy dog's back.
