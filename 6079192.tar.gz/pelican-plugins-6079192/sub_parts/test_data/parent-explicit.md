title: Explicit sub-article
tags: atag
slug: parent--explicit

Explicit sub-article, based on explicit slug.
