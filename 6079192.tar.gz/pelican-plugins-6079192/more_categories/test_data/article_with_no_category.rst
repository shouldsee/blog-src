Article with no category
========================
:date: 2018-11-04

This is an article with no category
